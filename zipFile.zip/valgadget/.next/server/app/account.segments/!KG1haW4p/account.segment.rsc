1:"$Sreact.fragment"
2:I[90861,["/_next/static/chunks/0nvu9q0ufa1df.js","/_next/static/chunks/0_tqqgj77ae9y.js"],"default"]
3:I[57834,["/_next/static/chunks/0nvu9q0ufa1df.js","/_next/static/chunks/0_tqqgj77ae9y.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"hWhDJL4iJkdc7HYmb-25o"}
