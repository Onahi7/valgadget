1:"$Sreact.fragment"
2:I[38514,["/_next/static/chunks/0nvu9q0ufa1df.js","/_next/static/chunks/0_tqqgj77ae9y.js","/_next/static/chunks/0gvia1q8whx3j.js","/_next/static/chunks/16ajlwm36jp0~.js","/_next/static/chunks/17gyr1huzfxcl.js","/_next/static/chunks/0tkt25eyxfe78.js","/_next/static/chunks/0x85mcvyus5q_.js","/_next/static/chunks/08djn1n8rajke.js","/_next/static/chunks/0tn2iyw2u4d_..js"],"AdminDashboardClient"]
3:I[46608,["/_next/static/chunks/0nvu9q0ufa1df.js","/_next/static/chunks/0_tqqgj77ae9y.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/0tn2iyw2u4d_..js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"hWhDJL4iJkdc7HYmb-25o"}
5:null
