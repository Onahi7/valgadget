var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/coupons/validate/route.js")
R.c("server/chunks/[root-of-the-server]__0shj7bh._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_coupons_validate_route_actions_0n4390i.js")
R.m(54299)
module.exports=R.m(54299).exports
