var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/imagekit/auth/route.js")
R.c("server/chunks/[root-of-the-server]__01k9_fh._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/0-5p_next_dist_esm_build_templates_app-route_0x~i08a.js")
R.c("server/chunks/_next-internal_server_app_api_imagekit_auth_route_actions_07yl.y2.js")
R.m(98359)
module.exports=R.m(98359).exports
