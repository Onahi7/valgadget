var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/addresses/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__11y8q.o._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_addresses_[id]_route_actions_0pcx_iw.js")
R.m(78478)
module.exports=R.m(78478).exports
