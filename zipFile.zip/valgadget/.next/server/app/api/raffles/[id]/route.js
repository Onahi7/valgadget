var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/raffles/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0sr-5.7._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_raffles_[id]_route_actions_0k5xy~d.js")
R.m(65144)
module.exports=R.m(65144).exports
