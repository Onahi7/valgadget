var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/related/route.js")
R.c("server/chunks/[root-of-the-server]__04ervmi._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_related_route_actions_0f6f713.js")
R.m(49005)
module.exports=R.m(49005).exports
