var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/reviews/route.js")
R.c("server/chunks/[root-of-the-server]__0h0.i.1._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_reviews_route_actions_00-gv0u.js")
R.m(30009)
module.exports=R.m(30009).exports
