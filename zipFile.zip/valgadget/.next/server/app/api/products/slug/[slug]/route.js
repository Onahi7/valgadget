var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/slug/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__0m0qkwz._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/_next-internal_server_app_api_products_slug_[slug]_route_actions_06pg3-_.js")
R.m(86927)
module.exports=R.m(86927).exports
