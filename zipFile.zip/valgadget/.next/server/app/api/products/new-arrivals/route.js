var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/new-arrivals/route.js")
R.c("server/chunks/[root-of-the-server]__0hda9ei._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/_next-internal_server_app_api_products_new-arrivals_route_actions_0c~zqe6.js")
R.m(38430)
module.exports=R.m(38430).exports
