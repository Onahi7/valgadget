var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/featured/route.js")
R.c("server/chunks/[root-of-the-server]__0msa5.g._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/_next-internal_server_app_api_products_featured_route_actions_13jbipc.js")
R.m(91108)
module.exports=R.m(91108).exports
