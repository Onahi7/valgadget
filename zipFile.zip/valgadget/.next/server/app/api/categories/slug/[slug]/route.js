var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/slug/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__12pbk46._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/_next-internal_server_app_api_categories_slug_[slug]_route_actions_0e_8_l0.js")
R.m(82542)
module.exports=R.m(82542).exports
