var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0hwpir5._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/_next-internal_server_app_api_categories_[id]_route_actions_0e4a1xn.js")
R.m(47492)
module.exports=R.m(47492).exports
