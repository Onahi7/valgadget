var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/route.js")
R.c("server/chunks/[root-of-the-server]__0g5z.eo._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/_next-internal_server_app_api_categories_route_actions_0qw-f-9.js")
R.m(53414)
module.exports=R.m(53414).exports
