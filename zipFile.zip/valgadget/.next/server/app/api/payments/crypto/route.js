var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/crypto/route.js")
R.c("server/chunks/[root-of-the-server]__03z2iir._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_crypto_route_actions_0wceu7a.js")
R.m(63135)
module.exports=R.m(63135).exports
