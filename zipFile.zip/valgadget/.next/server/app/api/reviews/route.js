var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reviews/route.js")
R.c("server/chunks/[root-of-the-server]__0gydqhu._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_reviews_route_actions_0jw7amc.js")
R.m(40449)
module.exports=R.m(40449).exports
