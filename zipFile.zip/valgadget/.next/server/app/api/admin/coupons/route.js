var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/coupons/route.js")
R.c("server/chunks/[root-of-the-server]__01a5b48._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_coupons_route_actions_0negxw0.js")
R.m(99710)
module.exports=R.m(99710).exports
