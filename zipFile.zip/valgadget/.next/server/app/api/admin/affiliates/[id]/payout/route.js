var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/affiliates/[id]/payout/route.js")
R.c("server/chunks/[root-of-the-server]__0w6y1qi._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_affiliates_[id]_payout_route_actions_0~jsjj4.js")
R.m(20275)
module.exports=R.m(20275).exports
