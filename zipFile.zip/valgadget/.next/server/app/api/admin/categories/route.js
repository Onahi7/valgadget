var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/categories/route.js")
R.c("server/chunks/[root-of-the-server]__0~7i5bx._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_categories_route_actions_0y3dem7.js")
R.m(27865)
module.exports=R.m(27865).exports
