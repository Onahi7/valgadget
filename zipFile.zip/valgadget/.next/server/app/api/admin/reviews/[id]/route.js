var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/reviews/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__087t1_f._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_reviews_[id]_route_actions_0xowc1m.js")
R.m(47271)
module.exports=R.m(47271).exports
