var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/products/route.js")
R.c("server/chunks/[root-of-the-server]__08hbcvi._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_products_route_actions_0_t2yuk.js")
R.m(27913)
module.exports=R.m(27913).exports
