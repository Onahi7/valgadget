var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/affiliate-payouts/route.js")
R.c("server/chunks/[root-of-the-server]__0o7z4_g._.js")
R.c("server/chunks/lib_server_auth-helpers_ts_0b21gk2._.js")
R.c("server/chunks/[root-of-the-server]__0js4aod._.js")
R.c("server/chunks/[root-of-the-server]__0k6~ide._.js")
R.c("server/chunks/0-5p_next_0yichxz._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_affiliate-payouts_route_actions_08k7-e3.js")
R.m(16760)
module.exports=R.m(16760).exports
